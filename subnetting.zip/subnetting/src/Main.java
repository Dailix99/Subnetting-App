import java.util.*;
import java.util.regex.Pattern;


public class Main {

    public static void main(String[] args) {



        Vector<PC> r =new Vector<>();


        SMvariabile v=new SMvariabile(); //creo oggetto di tipo SM variabile
        //v.subnettingvariabile();

        SMfissa f=new SMfissa(); //creo oggetto di tipo SM variabile
        //f.subnettingfissa();

        SMfissahost fh=new SMfissahost(); //creo oggetto di tipo SM variabile
        fh.subnettingfissahost();




   /*

                    System.out.println("\ninserisci l'indirizzo ip dell'host");
                    ip = in.nextLine();

                    // Parse IP parts into an int array
                    int[] iph = new int[4];
                    String[] dividi = ip.split("\\.");

                    for (i = 0; i < 4; i++) {
                        iph[i] = Integer.parseInt(dividi[i]);
                    }


*/





    }
}