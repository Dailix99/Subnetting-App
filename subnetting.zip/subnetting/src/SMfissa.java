import java.util.Scanner;
import java.util.*;


public class SMfissa {
    int scelta,conts=1,sottoreti,barrarete,numeropc=0,tothost=0,dim=0,cont=1,bithost,bitsm,available_host;
    int c=1,h,cont_oggetti=0,inizio_range=0,fine_range=0,i,calcolofine=0,g=0,b=0,rete=0,numsottoreti;
    int spreco;
    double host;
    String iphost;
    String gateway;
    String broadcast;
    String iprete;

    Scanner in = new Scanner(System.in);


    public void subnettingfissa() {


        int[] iparrayrete;
        do {
            //configurazione indirizzo di rete classe C
            System.out.print("inserise i byte da assegnare alla rete: /");
            barrarete=in.nextInt();

            in.nextLine();

            System.out.print("inserise l'ip da assegnare alla rete: ");
            iprete=in.nextLine();




            // Parse IP parts into an int array
            iparrayrete = new int[4];
            String[] parts = iprete.split("\\.");

            for (i = 0; i < 4; i++) {
                iparrayrete[i] = Integer.parseInt(parts[i]);
                System.out.println(iparrayrete[i]);
            }

            if (iparrayrete[0] <= 191 && iparrayrete[0] >= 128) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe B,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] <= 127 ) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe A,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] >= 224 && iparrayrete[0] <= 239) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe D,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] >= 240 && iparrayrete[0] <= 255) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe E,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if(iparrayrete[0] > 255){
                System.out.println("ERRORE: ripetere l'operazione affinche' l'indizzo sia di classe C");
            }


            if (iparrayrete[3] != 0) {
                System.out.println("ERRORE: indirizzo di rete non conforme,inserire un indirizzo di rete che finisca con: *.*.*.0");
            }



        } while (iparrayrete[0] <= 191 && iparrayrete[0] >= 128 || iparrayrete[0] <= 127 || iparrayrete[0] >= 224 && iparrayrete[0] <= 239  ||  iparrayrete[0] >= 240 && iparrayrete[0] <= 255 ||  iparrayrete[0] > 255   || iparrayrete[3] != 0 );


        //definizione array per le caratteristiche di ciascuna sottorete

        dim = 60; //massina numero di sottoreti

        int[] gatewayh = new int[dim];
        int[] broadcasth = new int[dim];
        int[] calcolohost = new int[dim];
        String[] subnetmask = new String[dim];


        Rete r[] = new Rete[dim];

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//configurazione sottoreti(ip rete,range,broadcast,gateway,subnetmask,%spreco)

        i = 0; //scorre le sottoreti

        System.out.print("quante sottoreti a maschera fissa vuoi generare? ");
        numsottoreti=in.nextInt();

        do {


            if (tothost <=256 ) {

                System.out.println("\n"+cont+ " sottorete " );

                bithost=32-barrarete;

                host= Math.pow(2, bithost);

                calcolohost[i]= (int) host;


                tothost = tothost + calcolohost[i];


                System.out.println("bit host: 2^" + bithost + "=" + calcolohost[i]);
                System.out.println("HOST necessari per realizzare questa sottorete: " + calcolohost[i]);


                bitsm = 32 - bithost;
                System.out.println("bit subnetmask: " + bitsm + " (32-" + bithost + ")");


                //configurazione delle subnet mask
                switch (bitsm) {
                    case 24:
                        subnetmask[i]="255.255.255.0";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 25:
                        subnetmask[i]="255.255.255.128";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;


                    case 26:
                        subnetmask[i]="255.255.255.192";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 27:
                        subnetmask[i]="255.255.255.224";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 28:
                        subnetmask[i]="255.255.255.240";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 29:
                        subnetmask[i]="255.255.255.248";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 30:
                        subnetmask[i]="255.255.255.252";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;



                }



                if (i == 0) {  //configurazione 1 sottorete


                    inizio_range = iparrayrete[3] + 1;
                    fine_range = calcolohost[i] - 3;

                    System.out.println("indirizzo di rete: " + iprete);

                    System.out.print("RANGE host:  " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + inizio_range + " - " + +iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + fine_range);
                    available_host=fine_range;
                    System.out.println(" per un totale di " + available_host + " host disponibili");


                    gatewayh[i] = calcolohost[i] - 2;
                    g = gatewayh[i];

                    broadcasth[i] = calcolohost[i] - 1;
                    b = broadcasth[i];

                    System.out.println("indirizzo gateway: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + gatewayh[i]);
                    System.out.println("indirizzo broadcast: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + broadcasth[i]);


                    r[i] = new Rete(iprete, calcolohost[i]);

                } else if (tothost <= 256 && i > 0) { //configuro le restanti sottoreti

                    rete = rete + calcolohost[i - 1];

                    System.out.println("indirizzo di rete: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + rete);


                    inizio_range = inizio_range + calcolohost[i - 1];

                    calcolofine = fine_range + calcolohost[i];
                    fine_range = calcolofine;

                    System.out.print("RANGE:" + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + inizio_range + " - " + +iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + fine_range);
                    available_host=(fine_range-inizio_range)+1;
                    System.out.println(" per un totale di " + available_host + " host disponibili");


                    g = g + calcolohost[i];
                    gatewayh[i] = g;

                    b = b + calcolohost[i];
                    broadcasth[i] = b;

                    System.out.println("indirizzo gateway: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + gatewayh[i]);
                    System.out.println("indirizzo broadcast: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + broadcasth[i]);


                    r[i] = new Rete(iprete, calcolohost[i]);

                }//chiudo else if(i<0)

            }//chiudo if (tothost <= 256 && numeropc < 126)

            if (tothost > 256) {
                tothost = tothost - calcolohost[i];
                i--;
                cont--;
                System.out.println("\nERRORE:la somma degli host di ciascuna sottorete e' superiore a 256,per cui non e' possibile implementare questa sottorete dato il numero di pc troppo elevato");
            }

            i++;
            cont++;
            numsottoreti--;


        } while (tothost < 256 && numsottoreti!=0); //rifeto fino a quando tothost non e' minore di 256 o  il numero di sottoreti indicato giunge al termine



    }//chiudo metodo smvariabile



}//chiudo classe

