public class Rete {

    public String iprete;
    public int numeropc;



    public Rete(String ipr,int numeropc) {
        this.iprete=ipr;
        this.numeropc=numeropc;
    }






}