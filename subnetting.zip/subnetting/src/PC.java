public class PC extends Rete{
    public String ip;
    public String subnetmask;
    public String gateway;
    public String broadcast;

    public PC(String ipr,int numpc,String ip,String sb,String gate,String broad)
    {
        super(ipr,numpc);
        this.ip=ip;
        this.subnetmask=sb;
        this.gateway=gate;
        this.broadcast=broad;
    }




}
