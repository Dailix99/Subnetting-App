import java.util.Scanner;

public class SMfissahost {

    int scelta,conts=1,sottoreti,barrarete,numeropc=0,tothost=0,dim=0,cont=1,bithost,bitsm,available_host,calcolohost;
    int c=1,h,cont_oggetti=0,inizio_range=0,fine_range=0,i,calcolofine=0,g=0,b=0,rete=0,hostpredefiniti,dimensionesup;
    boolean stop;
    int spreco;
    double host;
    String iphost;
    String gateway;
    String broadcast;
    String iprete;

    Scanner in = new Scanner(System.in);


    public void subnettingfissahost() {


        int[] iparrayrete;
        do {
            //configurazione indirizzo di rete classe C
            System.out.println("inserise l'ip da assegnare alla rete: ");
            iprete=in.nextLine();




            // Parse IP parts into an int array
            iparrayrete = new int[4];
            String[] parts = iprete.split("\\.");

            for (i = 0; i < 4; i++) {
                iparrayrete[i] = Integer.parseInt(parts[i]);
                System.out.println(iparrayrete[i]);
            }

            if (iparrayrete[0] <= 191 && iparrayrete[0] >= 128) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe B,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] <= 127 ) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe A,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] >= 224 && iparrayrete[0] <= 239) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe D,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if (iparrayrete[0] >= 240 && iparrayrete[0] <= 255) {
                System.out.println("ERRORE:l'indirizzo di rete inserito e' di classe E,ripetere l'operazione affinche' l'indizzo sia di classe C");
            } else if(iparrayrete[0] > 255){
                System.out.println("ERRORE: ripetere l'operazione affinche' l'indizzo sia di classe C");
            }


            if (iparrayrete[3] != 0) {
                System.out.println("ERRORE: indirizzo di rete non conforme,inserire un indirizzo di rete che finisca con: *.*.*.0");
            }



        } while (iparrayrete[0] <= 191 && iparrayrete[0] >= 128 || iparrayrete[0] <= 127 || iparrayrete[0] >= 224 && iparrayrete[0] <= 239  ||  iparrayrete[0] >= 240 && iparrayrete[0] <= 255 ||  iparrayrete[0] > 255   || iparrayrete[3] != 0 );


        //definizione array per le caratteristiche di ciascuna sottorete

        dim = 60; //massina numero di sottoreti

        int[] gatewayh = new int[dim];
        int[] broadcasth = new int[dim];
        String[] subnetmask = new String[dim];


        Rete r[] = new Rete[dim];

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//configurazione sottoreti(ip rete,range,broadcast,gateway,subnetmask,%spreco)

        i = 0; //scorre le sottoreti
        stop=true;



        hostpredefiniti=256; //inizializzazione iniziale

        do {
            dimensionesup=hostpredefiniti-3; //calcolo la dimensione massima da non superare considerando indirizzo rete,broadcast e gateway
            do {
                System.out.println("\ninserisci il numero di pc della " + cont + " sottorete ");
                numeropc = in.nextInt();
                if (numeropc >= 126) {
                    i--;
                    cont--;
                    System.out.println("\nERRORE:non e' possibile fare subnetting se per coprire il numero pc si necessita di 256 host disponibili (3 indirizzi sono occupati dal:  gateway/broadcast/iprete)");
                }
                if(numeropc>dimensionesup){
                    System.out.println("il numero di pc non può essere soddisfatto data la dimensione fissa delle sottoreti");
                }
            } while ((numeropc >= 126 && tothost > 256) || numeropc>dimensionesup);


            if (tothost <= 256 && numeropc < 126) {

                System.out.println("\n"+cont+ " sottorete " );


                if(stop==true) {
                    c = 1;
                    do {
                        h = 0;
                        calcolohost = 0;
                        calcolohost= 2 * c;
                        c = c * 2;
                        h = calcolohost - numeropc;

                        gatewayh[i] = calcolohost;
                        broadcasth[i] = calcolohost;

                        bithost++;

                    } while (h < 3);
                    hostpredefiniti=calcolohost;
                }

                tothost = tothost + hostpredefiniti;




                System.out.println("bit host: 2^" + bithost + "=" + hostpredefiniti);
                System.out.println("HOST necessari per realizzare questa sottorete: " + hostpredefiniti);
                spreco = 100 - ((numeropc * 100) / hostpredefiniti);
                System.out.println("lo spreco di indirizzi e' equivalente a: " + spreco + "%");

                bitsm = 32 - bithost;
                System.out.println("bit subnetmask: " + bitsm + " (32-" + bithost + ")");




                //configurazione delle subnet mask
                switch (bitsm) {
                    case 24:
                        subnetmask[i]="255.255.255.0";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 25:
                        subnetmask[i]="255.255.255.128";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;


                    case 26:
                        subnetmask[i]="255.255.255.192";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 27:
                        subnetmask[i]="255.255.255.224";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 28:
                        subnetmask[i]="255.255.255.240";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 29:
                        subnetmask[i]="255.255.255.248";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;

                    case 30:
                        subnetmask[i]="255.255.255.252";
                        System.out.println("subnet mask: " + subnetmask[i] );
                        break;



                }



                if (i == 0) {  //configurazione 1 sottorete


                    inizio_range = iparrayrete[3] + 1;
                    fine_range = hostpredefiniti - 3;

                    System.out.println("indirizzo di rete: " + iprete);

                    System.out.print("RANGE host:  " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + inizio_range + " - " + +iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + fine_range);
                    available_host=fine_range;
                    System.out.println(" per un totale di " + available_host + " host disponibili");


                    gatewayh[i] = hostpredefiniti - 2;
                    g = gatewayh[i];

                    broadcasth[i] = hostpredefiniti - 1;
                    b = broadcasth[i];

                    System.out.println("indirizzo gateway: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + gatewayh[i]);
                    System.out.println("indirizzo broadcast: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + broadcasth[i]);


                    r[i] = new Rete(iprete, hostpredefiniti);

                } else if (tothost <= 256 && i > 0) { //configuro le restanti sottoreti


                    rete = rete + hostpredefiniti;

                    System.out.println("indirizzo di rete: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + rete);


                    inizio_range = inizio_range + hostpredefiniti;

                    calcolofine = fine_range + hostpredefiniti;
                    fine_range = calcolofine;

                    System.out.print("RANGE:" + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + inizio_range + " - " + +iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + fine_range);
                    available_host=(fine_range-inizio_range)+1;
                    System.out.println(" per un totale di " + available_host + " host disponibili");


                    g = g + hostpredefiniti;
                    gatewayh[i] = g;

                    b = b + hostpredefiniti;
                    broadcasth[i] = b;

                    System.out.println("indirizzo gateway: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + gatewayh[i]);
                    System.out.println("indirizzo broadcast: " + iparrayrete[0] + "." + iparrayrete[1] + "." + iparrayrete[2] + "." + broadcasth[i]);


                    r[i] = new Rete(iprete, hostpredefiniti);

                }//chiudo else if(i<0)

            }//chiudo if (tothost <= 256 && numeropc < 126)

            if (tothost > 256) {
                tothost = tothost - hostpredefiniti;
                i--;
                cont--;
                System.out.println("\nERRORE:la somma degli host di ciascuna sottorete e' superiore a 256,per cui non e' possibile implementare questa sottorete dato il numero di pc troppo elevato");
            }

            i++;
            cont++;
            stop=false;


        } while (tothost < 256 || numeropc >= 126); //rifeto fino a quando tothost non e' minore di 256 o il numero di pc inserito supera 126



    }//chiudo metodo smvariabile



}//chiudo classe



